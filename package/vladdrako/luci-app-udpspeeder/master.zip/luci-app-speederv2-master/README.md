# luci-app-speederv2 [![Build Status](https://travis-ci.org/haodong/luci-app-speederv2.svg?branch=master)](https://travis-ci.org/haodong/luci-app-speederv2) ![Relase Version](https://img.shields.io/github/release/haodong/luci-app-speederv2.svg) ![Releases Downloads](https://img.shields.io/github/downloads/haodong/luci-app-speederv2/total.svg)
适配于openwrt的UDPspeeder辅助插件

使用方法：
1. [下载](https://github.com/haodong/luci-app-speederv2/releases)或编译得到ipk，并安装。
2. 从[UDPspeeder](https://github.com/wangyu-/UDPspeeder/releases)下载自己适配型号的二进制文件，放入`/usr/bin/speederv2`。
3. 重启路由器即可使用。
